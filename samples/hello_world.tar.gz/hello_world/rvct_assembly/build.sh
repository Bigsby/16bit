#!/bin/sh

armasm -o hello_world hello_world.s

