#!/bin/sh

gcc -o hello_world hello_world.s

